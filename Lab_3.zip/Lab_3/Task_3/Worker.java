import org.zeromq.ZContext;
import org.zeromq.ZMQ;
import org.zeromq.SocketType;

public class Worker {
    public static void main(String[] args) {
        try (ZContext context = new ZContext()) {
            ZMQ.Socket pullSocket = context.createSocket(SocketType.PULL);
            pullSocket.connect("tcp://localhost:5556");

            System.out.println("Worker connected to Task Queue and ready to receive tasks...");

            while (!Thread.currentThread().isInterrupted()) {
                String task = pullSocket.recvStr(0);
                if (task != null) {
                    System.out.println("Received task: " + task);
                    Thread.sleep(1000);
                    System.out.println("Completed task: " + task);
                } else {
                    System.out.println("No task received. Still waiting...");
                }
            }
        } catch (Exception e) {
            System.err.println("An error occurred in the Worker: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

