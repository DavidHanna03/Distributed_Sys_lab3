import org.zeromq.ZContext;
import org.zeromq.ZMQ;
import org.zeromq.SocketType;

import java.util.LinkedList;
import java.util.Queue;

public class TaskQueue {
    public static void main(String[] args) {
        try (ZContext context = new ZContext()) {
            ZMQ.Socket pullSocket = context.createSocket(SocketType.PULL);
            ZMQ.Socket responseSocket = context.createSocket(SocketType.PUSH);
            ZMQ.Socket requestSocket = context.createSocket(SocketType.PULL);

            String taskPublisherAddress = "tcp://*:5555";
            String workerSendAddress = "tcp://*:5556";
            String workerRequestAddress = "tcp://*:5557";

            pullSocket.bind(taskPublisherAddress);
            responseSocket.bind(workerSendAddress);
            requestSocket.bind(workerRequestAddress);

            System.out.println("Task Queue is up and running...");
            System.out.println("Listening for tasks from the publisher at " + taskPublisherAddress);
            System.out.println("Listening for worker requests at " + workerRequestAddress);

            Queue<String> taskQueue = new LinkedList<>();
            int maxQueueSize = 50;

            while (!Thread.currentThread().isInterrupted()) {
                String task = pullSocket.recvStr(ZMQ.NOBLOCK);
                if (task != null) {
                    if (taskQueue.size() >= maxQueueSize) {
                        System.out.println("Queue is full. Removing the oldest task to make space.");
                        taskQueue.poll();
                    }
                    taskQueue.offer(task);
                    System.out.println("Received and enqueued task: " + task);
                }

                String workerRequest = requestSocket.recvStr(ZMQ.NOBLOCK);
                if (workerRequest != null && !taskQueue.isEmpty()) {
                    String nextTask = taskQueue.poll();
                    responseSocket.send(nextTask.getBytes(ZMQ.CHARSET), 0);
                    System.out.println("Dispatched task to worker: " + nextTask);
                } else if (workerRequest != null) {
                    System.out.println("Worker requested a task, but the queue is empty.");
                }

                Thread.sleep(100);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in the Task Queue: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

