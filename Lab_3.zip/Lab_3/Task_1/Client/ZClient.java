import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class ZClient {
    public static void main(String[] args) {
        // Create a ZeroMQ context
        try (ZContext context = new ZContext()) {
            // Create a REQ socket (request socket) to send requests to the server
            ZMQ.Socket socket = context.createSocket(SocketType.REQ);
            socket.connect("tcp://localhost:5555"); // Connect to the server's address

            System.out.println("Client is connected to the server.");

            // Send a connection request to the server
            String request = "Client: Hello, server!";
            System.out.println("Sending request: " + request);
            socket.send(request.getBytes(ZMQ.CHARSET), 0);

            // Wait for a reply from the server
            String reply = socket.recvStr(0);
            System.out.println("Received reply from server: " + reply);
            System.out.println("Connection established successfully on the client side.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
