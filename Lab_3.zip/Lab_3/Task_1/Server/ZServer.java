import org.zeromq.SocketType;
import org.zeromq.ZContext;
import org.zeromq.ZMQ;

public class ZServer {
    public static void main(String[] args) {
        // Create a ZeroMQ context
        try (ZContext context = new ZContext()) {
            // Create a REP socket (reply socket) to receive requests from clients
            ZMQ.Socket socket = context.createSocket(SocketType.REP);
            socket.bind("tcp://*:5555"); // Bind to port 5555

            System.out.println("Server is up and running, waiting for connections...");

            // Loop to continuously listen for requests from clients
            while (!Thread.currentThread().isInterrupted()) {
                // Receive a message from the client
                String message = socket.recvStr(0);
                System.out.println("Received request from client: " + message);

                // Send a reply back to the client
                String reply = "Server: Connection established successfully!";
                socket.send(reply.getBytes(ZMQ.CHARSET), 0);
                System.out.println("Reply sent to client.");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
