import org.zeromq.ZContext;
import org.zeromq.ZMQ;
import org.zeromq.SocketType;

public class TaskPublisher {
    public static void main(String[] args) {
        // Setup the ZeroMQ context and PUSH socket
        try (ZContext context = new ZContext()) {
            // Create a PUSH socket
            ZMQ.Socket pushSocket = context.createSocket(SocketType.PUSH);
            
            // Connect to the Task Queue's address
            String taskQueueAddress = "tcp://localhost:5555"; // port5555
            pushSocket.connect(taskQueueAddress);
            System.out.println("Task Publisher connected to Task Queue at " + taskQueueAddress);

            // Generate and send tasks
            int taskCount = 1;
            while (true) {
                // Creating task msg
                String task = "Task " + taskCount + ": Perform some work";
                System.out.println("Sending: " + task);

                // Send the task to the Task Queue
                pushSocket.send(task.getBytes(ZMQ.CHARSET), 0);

                // Increment the task counter
                taskCount++;

                
                Thread.sleep(1000); // 1-second delay between tasks
            }
        } catch (Exception e) {
            // Handle the exceptions 
            System.err.println("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

