import org.zeromq.ZContext;
import org.zeromq.ZMQ;
import org.zeromq.SocketType;

public class Worker {
    public static void main(String[] args) {
        // Set up ZeroMQ context for the worker
        try (ZContext context = new ZContext()) {
            // Create a PUSH socket for sending requests to the Task Queue
            ZMQ.Socket pushSocket = context.createSocket(SocketType.PUSH);
            pushSocket.connect("tcp://localhost:5557"); // Connect to the Task Queue's request socket

            // Create a PULL socket for receiving tasks from the Task Queue
            ZMQ.Socket pullSocket = context.createSocket(SocketType.PULL);
            pullSocket.connect("tcp://localhost:5556"); // Connect to the Task Queue's task distribution socket

            System.out.println("Worker connected to Task Queue and ready to request tasks...");

            // Main loop: Continuously request tasks and process them
            while (!Thread.currentThread().isInterrupted()) {
                // Step 1: Send a request for a new task
                pushSocket.send("Requesting task", 0);
                System.out.println("Sent request for task.");

                // Step 2: Receive the next task from the Task Queue
                String task = pullSocket.recvStr(0);
                if (task != null) {
                    System.out.println("Received task: " + task);
                    // Simulate processing the task
                    Thread.sleep(1000); // Simulate task processing for 1 second
                    System.out.println("Completed task: " + task);
                } else {
                    System.out.println("No task received. Waiting for the next task...");
                }

                // Pause briefly before the next request
                Thread.sleep(500);
            }
        } catch (Exception e) {
            System.err.println("An error occurred in the Worker: " + e.getMessage());
            e.printStackTrace();
        }
    }
}

